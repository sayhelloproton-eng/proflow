# ProFlow Test/Ops Knowledge Smoke

PROFLOW_KNOWLEDGE_SMOKE_TOKEN=PF-REAL2-TEST-OPS-001
This file is a deployment-time Custom GPT Knowledge placeholder.
