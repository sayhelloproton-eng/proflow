# ProFlow Product Knowledge Smoke

PROFLOW_KNOWLEDGE_SMOKE_TOKEN=PF-REAL2-PRODUCT-001
This file is a deployment-time Custom GPT Knowledge placeholder.
